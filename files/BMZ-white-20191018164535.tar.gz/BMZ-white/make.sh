 #!/bin/bash

mkdir ./png
mkdir ./cursors

find ./svg -name "*.svg" | parallel -I% --max-args 1 inkscape -f % -e %.png

mv svg/*.png ./png
mv svg/animations/*.png ./png

echo "34 4 1 alias.svg.png 10 replace" >  ./png/alias.conf
echo "34 8 15 all-scroll.svg.png 10 replace" >  ./png/all-scroll.conf
echo "34 18 18 cell.svg.png 10 replace" >  ./png/cell.conf
echo "34 15 15 col-resize.svg.png 10 replace" >  ./png/col-resize.conf
echo "34 4 1 copy.svg.png 10 replace" >  ./png/copy.conf
echo "34 14 14 crosshair.svg.png 10 replace" >  ./png/crosshair.conf
echo "34 4 1 default.svg.png 10 replace" >  ./png/default.conf
echo "34 4 1 no-drop.svg.png 10 replace" >  ./png/no-drop.conf
echo "34 18 18 not-allowed.svg.png 10 replace" > ./png/not-allowed.conf
echo "34 15 15 row-resize.svg.png 10 replace" >  ./png/row-resize.conf
echo "34 5 10 text.svg.png 10 replace" >  ./png/text.conf
echo "34 10 3 vertical-text.svg.png 10 replace" >  ./png/vertical-text.conf
echo "34 4 1 help.svg.png 10 replace" >  ./png/help.conf
echo "34 4 1 move.svg.png 10 replace" >  ./png/move.conf
echo "34 8 0 pointer.svg.png 10 replace" >  ./png/pointer.conf

# Cursors from "nice to have" and "up for discussion" entries
echo "34 4 1 context-menu.svg.png 10 replace" >  ./png/context-menu.conf
echo "34 17 3 up-arrow.svg.png 10 replace" >  ./png/up-arrow.conf
echo "34 17 32 down-arrow.svg.png 10 replace" >  ./png/down-arrow.conf
echo "34 4 17 left-arrow.svg.png 10 replace" >  ./png/left-arrow.conf
echo "34 31 17 right-arrow.svg.png 10 replace" >  ./png/right-arrow.conf
echo "34 10 7 ew-resize.svg.png 10 replace" >  ./png/ew-resize.conf
echo "34 10 8 nesw-resize.svg.png 10 replace" >  ./png/nesw-resize.conf
echo "34 7 10 ns-resize.svg.png 10 replace" >  ./png/ns-resize.conf
echo "34 8 8 nwse-resize.svg.png 10 replace" >  ./png/nwse-resize.conf
echo "34 1 1 color-picker.svg.png 10 replace" >  ./png/color-picker.conf
echo "34 33 0 right-ptr.svg.png 10 replace" >  ./png/right-ptr.conf
echo "34 2 18 color-picker.svg.png 10 replace" >  ./png/color-picker.conf
echo "34 9 9 zoom-in.svg.png 10 replace" >  ./png/zoom-in.conf
echo "34 9 9 zoom-out.svg.png 10 replace" >  ./png/zoom-out.conf

# Cursors not in the spec, but nice to have for completeness
echo "34 8 15 grabbing.svg.png 10 replace" >  ./png/grabbing.conf
echo "34 1 18 pencil.svg.png 10 replace" >  ./png/pencil.conf
echo "34 18 18 pirate.svg.png 10 replace" >  ./png/pirate.conf
echo "34 18 18 X-cursor.svg.png 10 replace" >  ./png/X-cursor.conf

#making cursors
cd ./png

for file in *.conf
do
    cat $file | xcursorgen - ../cursors/${file%.*}
done


# Animated cursors
echo "Making animated cursors..."
cat > progress.conf <<EOF
34 3 1 wait1.svg.png 100
34 3 1 wait2.svg.png 100
34 3 1 wait3.svg.png 100
34 3 1 wait4.svg.png 100
34 3 1 wait5.svg.png 100
34 3 1 wait6.svg.png 100
34 3 1 wait7.svg.png 100
34 3 1 wait8.svg.png 100
EOF

cat > wait.conf <<EOF
34 11 11 progress8.svg.png 100
34 11 11 progress7.svg.png 100
34 11 11 progress6.svg.png 100
34 11 11 progress5.svg.png 100
34 11 11 progress4.svg.png 100
34 11 11 progress3.svg.png 100
34 11 11 progress2.svg.png 100
34 11 11 progress1.svg.png 100
EOF

xcursorgen wait.conf ../cursors/wait
xcursorgen progress.conf ../cursors/progress

cd ..

# Source links for legacy and hash cursors
echo "Making legacy links..."
cd cursors
source ../links.sh
cd ..
